# City Shooter - FPS Game

A fast-paced first-person shooter game built with Python and Ursina engine.

## Quick Start (Windows)

### Easiest Method - Automatic Setup:
1. **Download** all files from the repository
2. **Double-click** `INSTALL_AND_RUN.bat`
3. The script will:
   - Check if Python is installed
   - Install Python if needed
   - Download and install all required modules
   - Launch the game automatically

### Manual Setup (if batch file doesn't work):
1. **Install Python 3.10+** from https://www.python.org/downloads/
   - ⚠️ **IMPORTANT**: Check "Add Python to PATH" during installation
2. **Open Command Prompt** in the game folder
3. **Run these commands**:
   ```
   pip install -r requirements.txt
   python main.py
   ```

## System Requirements

- **OS**: Windows 7 or later
- **Python**: 3.10 or higher
- **RAM**: 4GB minimum
- **GPU**: Any modern graphics card
- **Disk Space**: 500MB

## Game Controls

### Movement & Look
- **WASD** - Move forward/backward/strafe
- **Mouse** - Look around
- **Shift** - Sprint (increases speed)

### Combat
- **Left Click** - Shoot
- **R** - Reload
- **Escape** - Quit game

## Gameplay

- **Objective**: Survive waves of enemies
- **Wave 1**: 5 enemies
- **Wave 2**: 10 enemies
- **Wave 3**: 15 enemies
- Each wave adds 5 more enemies
- Defeat all enemies to complete the wave
- Enemies spawn in a circle around the center
- Use buildings as cover

## Features

✅ Fast-paced FPS gameplay
✅ Progressive difficulty (waves increase)
✅ Multiple enemy types with different behaviors
✅ Sound effects for gunshots and reloading
✅ Health and ammo system
✅ Score and kill tracking
✅ Fullscreen immersive experience

## Troubleshooting

### "Python is not installed"
- Download Python from https://www.python.org/downloads/
- **Important**: Check "Add Python to PATH" during installation
- Restart your computer after installation

### "Module not found" error
- Open Command Prompt in the game folder
- Run: `pip install -r requirements.txt`
- Then run: `python main.py`

### Game runs slowly
- Close other applications
- Update your graphics drivers
- Lower your screen resolution if needed

### Sound not working
- Check that `gun_shot.mp3`, `gun-shot-e.mp3`, and `gun-reload.mp3` are in the game folder
- Check your system volume

## File Structure

```
City Shooter/
├── main.py                    (Main game file)
├── INSTALL_AND_RUN.bat        (Automatic setup script)
├── requirements.txt           (Python dependencies)
├── README.md                  (This file)
├── gun_shot.mp3              (Player gunshot sound)
├── gun-shot-e.mp3            (Enemy gunshot sound)
└── gun-reload.mp3            (Reload sound)
```

## Support

If you encounter any issues:
1. Make sure all files are in the same folder
2. Check that Python is properly installed
3. Try running the batch file again
4. Check the console output for error messages

## License

This game is provided as-is for personal use.

Enjoy the game! 🎮

