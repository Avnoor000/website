from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import random
from math import sin, cos, pi, sqrt

app = Ursina()
window.title = 'Ursina FPS — City Shooter'
window.borderless = True
window.fullscreen = True
mouse.locked = True

# ---------- Sound Effects ----------
# Create multiple instances for better overlapping
gunshot_sounds = [Audio('gun_shot.mp3', loop=False, autoplay=False, volume=1.5) for _ in range(5)]
gunshot_index = 0
enemy_gunshot_sounds = [Audio('gun-shot-e.mp3', loop=False, autoplay=False) for _ in range(5)]
enemy_gunshot_index = 0
reload_sound = Audio('gun-reload.mp3', loop=False, autoplay=False)

# ---------- Game State ----------

# ---------- Player ----------
player = FirstPersonController(height=2, speed=5, origin_y=-.5)
player.position = (25, 0, 25)  # Spawn away from center
player.cursor = Entity(parent=camera.ui, model='quad', color=color.white, scale=.008, rotation_z=0)
player.cursor.enabled = True
player.enabled = True

# ---------- Gun ----------
color_skin = color.rgb(255, 224, 189)
gun = Entity(model='cube', scale=(0.25, 0.18, 0.8), parent=camera, position=(0.4, -0.3, 1), origin=(0,0,-0.4), color=color.gray)
muzzle_flash = Entity(parent=gun, model='cube', scale=(0.1,0.1,0.1), position=(0,0,0.5), visible=False)
left_hand = Entity(model='sphere', scale=0.1, parent=gun, position=(-0.15, -0.05, -0.2), color=color_skin)
right_hand = Entity(model='sphere', scale=0.1, parent=gun, position=(0.15, -0.05, -0.2), color=color_skin)

# ---------- Environment ----------
ground = Entity(model='plane', scale=100, collider='box', color=color.dark_gray)
sky = Sky()

# ---------- Roads ----------
# Main cross roads - BLACK
road_main_h = Entity(model='cube', scale=(80, 0.1, 8), color=color.black, position=(0, 0.05, 0))
road_main_v = Entity(model='cube', scale=(8, 0.1, 80), color=color.black, position=(0, 0.05, 0))

# Yellow lane markings
for i in range(-35, 36, 10):
    Entity(model='cube', scale=(4, 0.12, 0.3), color=color.yellow, position=(i, 0.06, 0))
    Entity(model='cube', scale=(0.3, 0.12, 4), color=color.yellow, position=(0, 0.06, i))

# Side roads - BLACK
road_north = Entity(model='cube', scale=(6, 0.1, 30), color=color.black, position=(-20, 0.05, -20))
road_south = Entity(model='cube', scale=(6, 0.1, 30), color=color.black, position=(20, 0.05, 20))
road_east = Entity(model='cube', scale=(30, 0.1, 6), color=color.black, position=(20, 0.05, -20))
road_west = Entity(model='cube', scale=(30, 0.1, 6), color=color.black, position=(-20, 0.05, 20))

# ---------- Buildings - BRIGHT COLORS ----------
# Downtown tall buildings
building1 = Entity(model='cube', scale=(8,20,8), color=color.blue, position=(-15,10,-15), collider='box')
roof1 = Entity(model='cube', scale=(8.2,0.5,8.2), color=color.yellow, position=(-15,20,-15))

building2 = Entity(model='cube', scale=(10,25,10), color=color.cyan, position=(15,12.5,-15), collider='box')
roof2 = Entity(model='cube', scale=(10.2,0.5,10.2), color=color.red, position=(15,25,-15))

building3 = Entity(model='cube', scale=(7,18,12), color=color.violet, position=(-15,9,15), collider='box')
roof3 = Entity(model='cube', scale=(7.2,0.5,12.2), color=color.orange, position=(-15,18,15))

building4 = Entity(model='cube', scale=(12,22,9), color=color.magenta, position=(15,11,15), collider='box')
roof4 = Entity(model='cube', scale=(12.2,0.5,9.2), color=color.lime, position=(15,22,15))

# Mid-rise buildings
building5 = Entity(model='cube', scale=(6,12,6), color=color.green, position=(-30,6,-30), collider='box')
building6 = Entity(model='cube', scale=(5,10,8), color=color.orange, position=(30,5,-30), collider='box')
building7 = Entity(model='cube', scale=(7,14,5), color=color.azure, position=(-30,7,30), collider='box')
building8 = Entity(model='cube', scale=(6,11,7), color=color.pink, position=(30,5.5,30), collider='box')

# Small shops - BRIGHT
shop1 = Entity(model='cube', scale=(5,6,4), color=color.red, position=(-8,3,-8), collider='box')
shop2 = Entity(model='cube', scale=(4,6,5), color=color.yellow, position=(8,3,-8), collider='box')
shop3 = Entity(model='cube', scale=(5,6,4), color=color.lime, position=(-8,3,8), collider='box')
shop4 = Entity(model='cube', scale=(4,6,5), color=color.cyan, position=(8,3,8), collider='box')

# Corner buildings
corner1 = Entity(model='cube', scale=(8,15,8), color=color.orange, position=(-25,7.5,-8), collider='box')
corner2 = Entity(model='cube', scale=(8,15,8), color=color.violet, position=(25,7.5,-8), collider='box')
corner3 = Entity(model='cube', scale=(8,15,8), color=color.azure, position=(-25,7.5,8), collider='box')
corner4 = Entity(model='cube', scale=(8,15,8), color=color.magenta, position=(25,7.5,8), collider='box')

# ---------- Walls ----------
wall1 = Entity(model='cube', scale=(0.5,8,100), color=color.gray, position=(-50,4,0), collider='box')
wall2 = Entity(model='cube', scale=(0.5,8,100), color=color.gray, position=(50,4,0), collider='box')
wall3 = Entity(model='cube', scale=(100,8,0.5), color=color.gray, position=(0,4,-50), collider='box')
wall4 = Entity(model='cube', scale=(100,8,0.5), color=color.gray, position=(0,4,50), collider='box')

obstacles = [building1, building2, building3, building4, building5, building6, building7, building8, 
             shop1, shop2, shop3, shop4, corner1, corner2, corner3, corner4,
             wall1, wall2, wall3, wall4]

# ---------- Gameplay ----------
bullets = []
enemy_bullets = []
enemies = []
score = 0
kills = 0
current_wave = 1
enemies_spawned_this_wave = 0
shooters_spawned_this_wave = 0
wave_complete = False
magazine_size = 12
ammo = magazine_size
is_reloading = False
reload_time = 1.4
fire_rate = 0.14
time_since_last_shot = 0
player_max_health = 100
player_health = player_max_health
game_over_triggered = False
spawn_timer = 0
spawn_interval = 2.0

# Initialize game settings
enemies_per_wave = 5

# ---------- UI ----------
health_text = Text(text=f'Health: {player_health}', position=(-0.85, 0.45), scale=2, enabled=True, parent=camera.ui)
ammo_text = Text(text=f'Ammo: {ammo}/{magazine_size}', position=(0.65, 0.45), scale=2, enabled=True, parent=camera.ui)
score_text = Text(text=f'Score: {score}', position=(0.65, 0.38), scale=1.8, enabled=True, parent=camera.ui)
kills_text = Text(text=f'Kills: {kills}', position=(0.65, 0.31), scale=1.8, enabled=True, parent=camera.ui)
wave_text = Text(text=f'Wave: {current_wave}', position=(-0.85, 0.38), scale=2, color=color.cyan, enabled=True, parent=camera.ui)
enemies_left_text = Text(text=f'Enemies: {enemies_per_wave}', position=(-0.85, 0.31), scale=1.6, enabled=True, parent=camera.ui)
reload_hint = Text(text='Press R to Reload', position=(0.65, 0.24), scale=1.2, color=color.gray, enabled=True, parent=camera.ui)
wave_complete_text = Text(text='', position=(0, 0), scale=3, origin=(0,0), visible=False, parent=camera.ui)

def update_ui():
    health_text.text = f'Health: {int(player_health)}'
    if is_reloading:
        ammo_text.text = 'Reloading...'
        ammo_text.color = color.orange
    else:
        ammo_text.text = f'Ammo: {ammo}/{magazine_size}'
        ammo_text.color = color.white
    score_text.text = f'Score: {score}'
    kills_text.text = f'Kills: {kills}'
    wave_text.text = f'Wave: {current_wave}'
    # Show only total alive enemies
    alive_count = sum(1 for e in enemies if e.alive)
    enemies_left_text.text = f'Enemies: {alive_count}'

    # Show reload hint when low on ammo
    if ammo <= 3 and not is_reloading:
        reload_hint.color = color.yellow
        reload_hint.visible = True
    elif ammo == 0:
        reload_hint.color = color.red
        reload_hint.visible = True
    else:
        reload_hint.visible = False

# ---------- Collision ----------
def can_move(position, size=(1,1.5,1)):
    for obs in obstacles:
        obs_min = obs.position - obs.scale/2
        obs_max = obs.position + obs.scale/2
        ent_min = position - Vec3(size[0]/2, size[1]/2, size[2]/2)
        ent_max = position + Vec3(size[0]/2, size[1]/2, size[2]/2)
        if (ent_min.x <= obs_max.x and ent_max.x >= obs_min.x and
            ent_min.y <= obs_max.y and ent_max.y >= obs_min.y and
            ent_min.z <= obs_max.z and ent_max.z >= obs_min.z):
            return False
    return True

# ---------- Enemy ----------
class Enemy(Entity):
    def __init__(self, position=(0,0,0), speed=1.5, health=30, enemy_type='normal'):
        self.enemy_type = enemy_type

        # Set attributes based on type - ALL enemies have guns now
        if enemy_type == 'tank':
            scale = (1.5, 2, 1.5)
            color_choice = color.dark_gray
            speed = 1.2  # Increased from 0.8
            health = 80
            self.gun_damage = 5  # Tank does low damage
            self.shoot_cooldown_range = (3.0, 5.0)  # Slow fire rate
        elif enemy_type == 'fast':
            scale = (0.7, 1.2, 0.7)
            color_choice = color.orange
            speed = 3.5
            health = 15
            self.gun_damage = 4  # Fast does very low damage
            self.shoot_cooldown_range = (2.5, 4.0)  # Medium fire rate
        elif enemy_type == 'shooter':
            scale = (1, 1.5, 1)
            color_choice = color.yellow
            speed = 2.5  # Increased from 1.2
            health = 25
            self.gun_damage = 12  # Shooter does high damage
            self.shoot_cooldown_range = (1.5, 2.5)  # Fast fire rate
        else:  # normal
            scale = (1, 1.5, 1)
            color_choice = color.red
            speed = 1.5
            health = 30
            self.gun_damage = 8  # Normal does medium damage
            self.shoot_cooldown_range = (2.0, 3.5)  # Medium fire rate

        super().__init__(model='cube', color=color_choice, scale=scale, position=position, collider='box')
        self.speed = speed
        self.health = health
        self.max_health = health
        self.alive = True
        self.hit_flash_timer = 0
        self.push_back_timer = 0
        self.shoot_timer = 0
        self.shoot_cooldown = random.uniform(self.shoot_cooldown_range[0], self.shoot_cooldown_range[1])
        self.original_color = color_choice
        self.path_blocked_timer = 0

        # Add gun visual to all enemies
        self.gun_visual = Entity(model='cube', scale=(0.15, 0.1, 0.4), parent=self,
                                position=(0.3, 0.3, 0.5), color=color.black)

    def update(self):
        if not self.alive or game_over_triggered:
            return
        
        # Hit flash effect
        if self.hit_flash_timer > 0:
            self.hit_flash_timer -= time.dt
            if self.hit_flash_timer <= 0:
                self.color = self.original_color
        
        # Push back cooldown
        if self.push_back_timer > 0:
            self.push_back_timer -= time.dt
            return
        
        # Calculate direction to player
        target = player.position
        direction = Vec3(target.x - self.x, 0, target.z - self.z)
        dist_to_player = direction.length()
        direction = direction.normalized()
        
        # All enemies now shoot and chase
        self.shoot_timer += time.dt

        # Keep optimal distance (10-20 units) - move closer if far, back away if close
        if dist_to_player > 20:
            # Move closer
            proposed_position = self.position + direction * self.speed * time.dt
            if can_move(proposed_position, size=self.scale):
                self.position = proposed_position
                self.path_blocked_timer = 0
            else:
                self.path_blocked_timer += time.dt
        elif dist_to_player < 10:
            # Back away
            proposed_position = self.position - direction * self.speed * time.dt
            if can_move(proposed_position, size=self.scale):
                self.position = proposed_position
                self.path_blocked_timer = 0

        # Shoot at player
        if self.shoot_timer >= self.shoot_cooldown and dist_to_player < 30:
            self.shoot_at_player()
            self.shoot_timer = 0
            self.shoot_cooldown = random.uniform(self.shoot_cooldown_range[0], self.shoot_cooldown_range[1])

        # Try alternate paths if blocked for a while - improved pathfinding
        if self.path_blocked_timer > 0.3:
            # Try multiple directions to navigate around obstacles
            alt_directions = [
                Vec3(direction.z, 0, -direction.x),      # Right
                Vec3(-direction.z, 0, direction.x),      # Left
                Vec3(direction.z, 0, -direction.x) * 0.7 + direction * 0.3,  # Right-forward
                Vec3(-direction.z, 0, direction.x) * 0.7 + direction * 0.3,  # Left-forward
            ]
            for alt_dir in alt_directions:
                alt_pos = self.position + alt_dir.normalized() * self.speed * time.dt
                if can_move(alt_pos, size=self.scale):
                    self.position = alt_pos
                    self.path_blocked_timer = 0
                    break

        self.look_at(Vec3(target.x, self.y, target.z))
        
        # Melee damage
        global player_health
        if dist_to_player < 1.7:
            player_health -= 10 * time.dt
            if player_health <= 0 and not game_over_triggered:
                player_health = 0
                game_over()
            # Push enemy back
            push_direction = (self.position - player.position).normalized()
            self.position += push_direction * 2
            self.push_back_timer = 0.5

    def shoot_at_player(self):
        global player_health, enemy_bullets, enemy_gunshot_index
        # Create bullet
        bullet_start = self.position + Vec3(0, 0.5, 0)
        direction = (player.position - bullet_start).normalized()

        # Play enemy gunshot sound with rotation to avoid delays
        enemy_gunshot_sounds[enemy_gunshot_index].play()
        enemy_gunshot_index = (enemy_gunshot_index + 1) % len(enemy_gunshot_sounds)

        # Visual bullet
        eb = Entity(model='sphere', scale=0.15, position=bullet_start, color=color.red)
        eb.direction = direction
        eb.speed = 25
        eb.damage = self.gun_damage
        eb.lifetime = 0
        enemy_bullets.append(eb)

    def take_damage(self, amount):
        self.health -= amount
        self.color = color.white
        self.hit_flash_timer = 0.1
        if self.health <= 0:
            self.die()

    def die(self):
        global score, kills
        if not self.alive:
            return
        self.alive = False
        kills += 1
        
        # Different score values
        if self.enemy_type == 'tank':
            score += 25
        elif self.enemy_type == 'fast':
            score += 15
        elif self.enemy_type == 'shooter':
            score += 20
        else:
            score += 10
        
        # Death effect
        death_effect = Entity(model='sphere', position=self.position, scale=0.5, color=color.orange)
        death_effect.animate_scale(0, duration=0.3, curve=curve.out_quad)
        destroy(death_effect, delay=0.3)
        if self in enemies:
            enemies.remove(self)
        destroy(self)

# ---------- Spawning ----------
def spawn_enemy(x=0, y=0.75, z=0):
    """Spawn an enemy at the specified position"""
    global enemies_spawned_this_wave, shooters_spawned_this_wave

    if enemies_spawned_this_wave >= enemies_per_wave:
        return

    # Only spawn shooters now - all enemies have guns with different damage
    enemy_choice = 'shooter'
    shooters_spawned_this_wave += 1

    e = Enemy(position=(x, y, z), enemy_type=enemy_choice)
    enemies.append(e)
    enemies_spawned_this_wave += 1

def start_wave():
    global current_wave, enemies_per_wave, enemies_spawned_this_wave, shooters_spawned_this_wave, wave_complete, score

    wave_complete = False
    enemies_spawned_this_wave = 0
    shooters_spawned_this_wave = 0

    # Show wave start message
    wave_complete_text.text = f'WAVE {current_wave} START!'
    wave_complete_text.color = color.cyan
    wave_complete_text.visible = True
    invoke(setattr, wave_complete_text, 'visible', False, delay=2)

    # Spawn all enemies in a circle around center
    center_x, center_z = 0, 0
    circle_radius = 8  # Radius of the spawn circle

    for i in range(enemies_per_wave):
        # Calculate angle for this enemy (evenly distributed around circle)
        angle = (i / enemies_per_wave) * 2 * pi

        # Calculate position on circle
        x = center_x + cos(angle) * circle_radius
        z = center_z + sin(angle) * circle_radius
        y = 0.75

        spawn_enemy(x=x, y=y, z=z)

def complete_wave():
    global current_wave, enemies_per_wave, wave_complete, score, player_health
    
    wave_complete = True
    
    # Wave completion bonus
    wave_bonus = current_wave * 50
    score += wave_bonus
    
    # Heal player
    player_health = min(player_health + 30, player_max_health)
    
    # Show completion message
    wave_complete_text.text = f'WAVE {current_wave} COMPLETE!\n+{wave_bonus} Bonus'
    wave_complete_text.color = color.green
    wave_complete_text.visible = True
    invoke(setattr, wave_complete_text, 'visible', False, delay=3)
    
    # Next wave setup
    current_wave += 1
    
    enemies_per_wave += 5
    
    # Start next wave after delay
    invoke(start_wave, delay=3)

# ---------- Shooting ----------
def shoot():
    global ammo, time_since_last_shot, gunshot_index
    if game_over_triggered or is_reloading or ammo <= 0 or time_since_last_shot < fire_rate:
        if ammo <= 0:
            reload_mag()
        return
    ammo -= 1
    time_since_last_shot = 0
    # Play gunshot sound with rotation to avoid delays
    gunshot_sounds[gunshot_index].play()
    gunshot_index = (gunshot_index + 1) % len(gunshot_sounds)

    # Use raycast for better bullet detection
    start_pos = camera.world_position
    hit_info = raycast(start_pos, camera.forward, distance=100, ignore=[player, gun, muzzle_flash, left_hand, right_hand])

    # Visual bullet for feedback
    b = Entity(model='sphere', scale=0.12, position=start_pos + camera.forward * 1.2, color=color.yellow)

    # Check if we hit an enemy
    hit_enemy = hit_info.entity and hit_info.entity in enemies
    if hit_enemy:
        # Stop bullet at enemy position
        b.target_pos = hit_info.world_point
        b.animate_position(b.target_pos, duration=0.05, curve=curve.linear)
        destroy(b, delay=0.08)
        hit_info.entity.take_damage(20)
    else:
        # Bullet travels full distance if missed
        b.target_pos = hit_info.world_point if hit_info.hit else start_pos + camera.forward * 100
        b.animate_position(b.target_pos, duration=0.1, curve=curve.linear)
        destroy(b, delay=0.15)

    muzzle_flash.visible = True
    invoke(setattr, muzzle_flash, 'visible', False, delay=0.06)

    # Crosshair feedback
    player.cursor.color = color.red if hit_enemy else color.white
    invoke(setattr, player.cursor, 'color', color.white, delay=0.1)

    update_ui()

def reload_mag():
    global is_reloading
    if is_reloading or ammo == magazine_size or game_over_triggered:
        return
    is_reloading = True
    ammo_text.text = 'Reloading...'
    ammo_text.color = color.orange

    # Play reload sound
    reload_sound.play()

    # Reload animation - gun moves down and back up
    gun.animate_y(-0.6, duration=0.3, curve=curve.in_out_cubic)
    invoke(lambda: gun.animate_y(-0.3, duration=0.3, curve=curve.in_out_cubic), delay=0.8)

    invoke(finish_reload, delay=reload_time)

def finish_reload():
    global is_reloading, ammo
    if game_over_triggered:
        return
    ammo = magazine_size
    is_reloading = False
    ammo_text.color = color.white
    update_ui()

# ---------- Input ----------
def input(key):
    if key == 'left mouse down':
        shoot()
        return

    if game_over_triggered:
        if key == 'escape':
            application.quit()
        return

    if key == 'r':
        reload_mag()
    if key == 'escape':
        mouse.locked = False
        application.quit()

# ---------- Update ----------
def update():
    global time_since_last_shot, spawn_timer, player_health

    if game_over_triggered:
        return

    # Sprint
    if held_keys['shift']:
        player.speed = 10
        camera.fov = 110
    else:
        player.speed = 5
        camera.fov = 90

    time_since_last_shot += time.dt
    spawn_timer += time.dt

    # Efficient wave-based spawning with timer
    if not wave_complete and enemies_spawned_this_wave < enemies_per_wave:
        alive_enemies = sum(1 for e in enemies if e.alive)
        if alive_enemies < 8 and spawn_timer >= spawn_interval:
            spawn_enemy()
            spawn_timer = 0

    # Enemy bullet updates
    for eb in enemy_bullets[:]:
        eb.lifetime += time.dt
        eb.position += eb.direction * eb.speed * time.dt

        # Check if hit player
        if distance(eb.position, player.position) < 1.5:
            player_health -= eb.damage
            if player_health <= 0 and not game_over_triggered:
                player_health = 0
                game_over()
            destroy(eb)
            enemy_bullets.remove(eb)
            continue

        # Check if bullet hit a wall/obstacle
        hit_obstacle = False
        bullet_size = 0.15
        for obs in obstacles:
            obs_min = obs.position - obs.scale/2
            obs_max = obs.position + obs.scale/2
            bullet_min = eb.position - Vec3(bullet_size/2, bullet_size/2, bullet_size/2)
            bullet_max = eb.position + Vec3(bullet_size/2, bullet_size/2, bullet_size/2)

            # Check AABB collision
            if (bullet_min.x <= obs_max.x and bullet_max.x >= obs_min.x and
                bullet_min.y <= obs_max.y and bullet_max.y >= obs_min.y and
                bullet_min.z <= obs_max.z and bullet_max.z >= obs_min.z):
                hit_obstacle = True
                break

        if hit_obstacle:
            destroy(eb)
            if eb in enemy_bullets:
                enemy_bullets.remove(eb)
            continue

        # Remove old bullets
        if eb.lifetime > 5 or distance(eb.position, player.position) > 100:
            destroy(eb)
            if eb in enemy_bullets:
                enemy_bullets.remove(eb)

    # Check wave complete - more efficient
    if not wave_complete and enemies_spawned_this_wave >= enemies_per_wave:
        if not any(e.alive for e in enemies):
            complete_wave()

    update_ui()

# ---------- Game over ----------
def game_over():
    global game_over_triggered
    if game_over_triggered:
        return
    game_over_triggered = True
    Text('GAME OVER', origin=(0,0), scale=3, color=color.red)
    Text(f'Wave Reached: {current_wave}', origin=(0,0), y=-0.15, scale=1.6)
    Text(f'Total Kills: {kills}', origin=(0,0), y=-0.25, scale=1.6)
    Text(f'Final Score: {score}', origin=(0,0), y=-0.35, scale=1.8, color=color.yellow)
    mouse.locked = False
    invoke(application.quit, delay=5.0)

# ---------- Run ----------
# Start the first wave immediately
start_wave()

app.run()